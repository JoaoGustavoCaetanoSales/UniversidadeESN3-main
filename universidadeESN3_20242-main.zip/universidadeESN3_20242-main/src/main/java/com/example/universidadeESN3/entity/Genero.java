package com.example.universidadeESN3.entity;

public enum Genero {
    FEMININO,
    MASCULINO,
    OUTROS
}
