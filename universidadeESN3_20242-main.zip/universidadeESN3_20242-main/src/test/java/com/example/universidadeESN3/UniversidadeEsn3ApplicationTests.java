package com.example.universidadeESN3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversidadeEsn3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
